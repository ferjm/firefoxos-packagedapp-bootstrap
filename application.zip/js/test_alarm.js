if (navigator.mozAlarms == null) {
  alert('No alarms permissions!');
} else {
  alert('You have alarms permissions :)!');
}
